﻿namespace tictactoe
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.namePlayer1 = new System.Windows.Forms.Label();
            this.namePlayer2 = new System.Windows.Forms.Label();
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonPlace7 = new System.Windows.Forms.Button();
            this.buttonPlace8 = new System.Windows.Forms.Button();
            this.buttonPlace9 = new System.Windows.Forms.Button();
            this.buttonPlace4 = new System.Windows.Forms.Button();
            this.buttonPlace5 = new System.Windows.Forms.Button();
            this.buttonPlace6 = new System.Windows.Forms.Button();
            this.buttonPlace3 = new System.Windows.Forms.Button();
            this.buttonPlace2 = new System.Windows.Forms.Button();
            this.buttonPlace1 = new System.Windows.Forms.Button();
            this.avatarPlayer2 = new System.Windows.Forms.PictureBox();
            this.avatarPlayer1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.avatarPlayer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avatarPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // namePlayer1
            // 
            this.namePlayer1.AutoSize = true;
            this.namePlayer1.Location = new System.Drawing.Point(80, 25);
            this.namePlayer1.Name = "namePlayer1";
            this.namePlayer1.Size = new System.Drawing.Size(48, 13);
            this.namePlayer1.TabIndex = 11;
            this.namePlayer1.Text = "Player1 :";
            // 
            // namePlayer2
            // 
            this.namePlayer2.AutoSize = true;
            this.namePlayer2.Location = new System.Drawing.Point(620, 25);
            this.namePlayer2.Name = "namePlayer2";
            this.namePlayer2.Size = new System.Drawing.Size(48, 13);
            this.namePlayer2.TabIndex = 12;
            this.namePlayer2.Text = "Player 2:";
            // 
            // buttonBack
            // 
            this.buttonBack.Location = new System.Drawing.Point(355, 449);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(75, 50);
            this.buttonBack.TabIndex = 13;
            this.buttonBack.Text = "BACK";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // buttonPlace7
            // 
            this.buttonPlace7.Image = global::tictactoe.Properties.Resources.puste;
            this.buttonPlace7.Location = new System.Drawing.Point(255, 340);
            this.buttonPlace7.Name = "buttonPlace7";
            this.buttonPlace7.Size = new System.Drawing.Size(75, 75);
            this.buttonPlace7.TabIndex = 10;
            this.buttonPlace7.UseVisualStyleBackColor = true;
            this.buttonPlace7.Click += new System.EventHandler(this.buttonPlace7_Click);
            // 
            // buttonPlace8
            // 
            this.buttonPlace8.Image = global::tictactoe.Properties.Resources.puste;
            this.buttonPlace8.Location = new System.Drawing.Point(355, 340);
            this.buttonPlace8.Name = "buttonPlace8";
            this.buttonPlace8.Size = new System.Drawing.Size(75, 75);
            this.buttonPlace8.TabIndex = 9;
            this.buttonPlace8.UseVisualStyleBackColor = true;
            this.buttonPlace8.Click += new System.EventHandler(this.buttonPlace8_Click);
            // 
            // buttonPlace9
            // 
            this.buttonPlace9.Image = global::tictactoe.Properties.Resources.puste;
            this.buttonPlace9.Location = new System.Drawing.Point(455, 340);
            this.buttonPlace9.Name = "buttonPlace9";
            this.buttonPlace9.Size = new System.Drawing.Size(75, 75);
            this.buttonPlace9.TabIndex = 8;
            this.buttonPlace9.UseVisualStyleBackColor = true;
            this.buttonPlace9.Click += new System.EventHandler(this.buttonPlace9_Click);
            // 
            // buttonPlace4
            // 
            this.buttonPlace4.Image = global::tictactoe.Properties.Resources.puste;
            this.buttonPlace4.Location = new System.Drawing.Point(255, 250);
            this.buttonPlace4.Name = "buttonPlace4";
            this.buttonPlace4.Size = new System.Drawing.Size(75, 75);
            this.buttonPlace4.TabIndex = 7;
            this.buttonPlace4.UseVisualStyleBackColor = true;
            this.buttonPlace4.Click += new System.EventHandler(this.buttonPlace4_Click);
            // 
            // buttonPlace5
            // 
            this.buttonPlace5.Image = global::tictactoe.Properties.Resources.puste;
            this.buttonPlace5.Location = new System.Drawing.Point(355, 250);
            this.buttonPlace5.Name = "buttonPlace5";
            this.buttonPlace5.Size = new System.Drawing.Size(75, 75);
            this.buttonPlace5.TabIndex = 6;
            this.buttonPlace5.UseVisualStyleBackColor = true;
            this.buttonPlace5.Click += new System.EventHandler(this.buttonPlace5_Click);
            // 
            // buttonPlace6
            // 
            this.buttonPlace6.Image = global::tictactoe.Properties.Resources.puste;
            this.buttonPlace6.Location = new System.Drawing.Point(455, 250);
            this.buttonPlace6.Name = "buttonPlace6";
            this.buttonPlace6.Size = new System.Drawing.Size(75, 75);
            this.buttonPlace6.TabIndex = 5;
            this.buttonPlace6.UseVisualStyleBackColor = true;
            this.buttonPlace6.Click += new System.EventHandler(this.buttonPlace6_Click);
            // 
            // buttonPlace3
            // 
            this.buttonPlace3.Image = global::tictactoe.Properties.Resources.puste;
            this.buttonPlace3.Location = new System.Drawing.Point(455, 160);
            this.buttonPlace3.Name = "buttonPlace3";
            this.buttonPlace3.Size = new System.Drawing.Size(75, 75);
            this.buttonPlace3.TabIndex = 4;
            this.buttonPlace3.UseVisualStyleBackColor = true;
            this.buttonPlace3.Click += new System.EventHandler(this.buttonPlace3_Click);
            // 
            // buttonPlace2
            // 
            this.buttonPlace2.Image = global::tictactoe.Properties.Resources.puste;
            this.buttonPlace2.Location = new System.Drawing.Point(355, 160);
            this.buttonPlace2.Name = "buttonPlace2";
            this.buttonPlace2.Size = new System.Drawing.Size(75, 75);
            this.buttonPlace2.TabIndex = 3;
            this.buttonPlace2.UseVisualStyleBackColor = true;
            this.buttonPlace2.Click += new System.EventHandler(this.buttonPlace2_Click);
            // 
            // buttonPlace1
            // 
            this.buttonPlace1.Image = global::tictactoe.Properties.Resources.puste;
            this.buttonPlace1.Location = new System.Drawing.Point(255, 160);
            this.buttonPlace1.Name = "buttonPlace1";
            this.buttonPlace1.Size = new System.Drawing.Size(75, 75);
            this.buttonPlace1.TabIndex = 2;
            this.buttonPlace1.UseVisualStyleBackColor = true;
            this.buttonPlace1.Click += new System.EventHandler(this.buttonPlace1_Click);
            // 
            // avatarPlayer2
            // 
            this.avatarPlayer2.Location = new System.Drawing.Point(620, 50);
            this.avatarPlayer2.Name = "avatarPlayer2";
            this.avatarPlayer2.Size = new System.Drawing.Size(100, 100);
            this.avatarPlayer2.TabIndex = 1;
            this.avatarPlayer2.TabStop = false;
            // 
            // avatarPlayer1
            // 
            this.avatarPlayer1.Location = new System.Drawing.Point(80, 50);
            this.avatarPlayer1.Name = "avatarPlayer1";
            this.avatarPlayer1.Size = new System.Drawing.Size(100, 100);
            this.avatarPlayer1.TabIndex = 0;
            this.avatarPlayer1.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::tictactoe.Properties.Resources.tlo1;
            this.ClientSize = new System.Drawing.Size(784, 511);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.namePlayer2);
            this.Controls.Add(this.namePlayer1);
            this.Controls.Add(this.buttonPlace7);
            this.Controls.Add(this.buttonPlace8);
            this.Controls.Add(this.buttonPlace9);
            this.Controls.Add(this.buttonPlace4);
            this.Controls.Add(this.buttonPlace5);
            this.Controls.Add(this.buttonPlace6);
            this.Controls.Add(this.buttonPlace3);
            this.Controls.Add(this.buttonPlace2);
            this.Controls.Add(this.buttonPlace1);
            this.Controls.Add(this.avatarPlayer2);
            this.Controls.Add(this.avatarPlayer1);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.avatarPlayer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avatarPlayer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox avatarPlayer1;
        private System.Windows.Forms.PictureBox avatarPlayer2;
        private System.Windows.Forms.Button buttonPlace1;
        private System.Windows.Forms.Button buttonPlace2;
        private System.Windows.Forms.Button buttonPlace3;
        private System.Windows.Forms.Button buttonPlace4;
        private System.Windows.Forms.Button buttonPlace5;
        private System.Windows.Forms.Button buttonPlace6;
        private System.Windows.Forms.Button buttonPlace7;
        private System.Windows.Forms.Button buttonPlace8;
        private System.Windows.Forms.Button buttonPlace9;
        private System.Windows.Forms.Label namePlayer1;
        private System.Windows.Forms.Label namePlayer2;
        private System.Windows.Forms.Button buttonBack;
    }
}