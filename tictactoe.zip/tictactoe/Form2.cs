﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tictactoe
{
    public partial class Form2 : Form
    {
        public Form2(string playerName1, string playerName2, Image avatar1, Image avatar2)
        {
            InitializeComponent();
            namePlayer1.Text = "Player 1: " + playerName1;
            namePlayer2.Text = "Player 2: " + playerName2;
            avatarPlayer1.Image = avatar1;
            avatarPlayer2.Image = avatar2;
        }

        int moveIndex = 0;
        int[,] tab = { {0, 0, 0}, {0, 0, 0}, {0, 0, 0} };
        bool[] isChanged = { false, false, false, false, false, false, false, false, false, false };

        public void winCheck()
        {
            bool isWin = false;

            for (int i = 0; i < 3; i++)
            {
                if (isWin == false) 
                {
                    if (tab[i, 0] != 0 && tab[i, 0] == tab[i, 1] && tab[i, 0] == tab[i, 2])
                    {
                        programEnd(tab[i, 0], moveIndex, isWin);
                        isWin = true;
                        break;
                    }
                    if (tab[0, i] != 0 && tab[0, i] == tab[1, i] && tab[0, i] == tab[2, i])
                    {
                        programEnd(tab[0, i], moveIndex, isWin);
                        isWin = true;
                        break;
                    }
                }   
            }
            if (isWin == false)
            {
                if (tab[0, 0] != 0 && tab[0, 0] == tab[1, 1] && tab[0, 0] == tab[2, 2])
                {
                    programEnd(tab[0, 0], moveIndex, isWin);
                    isWin = true;
                }
                if (tab[0, 2] != 0 && tab[0, 2] == tab[1, 1] && tab[0, 2] == tab[2, 0])
                {
                    programEnd(tab[0, 2], moveIndex, isWin);
                    isWin = true;
                }
            }

            if (moveIndex == 9 && isWin == false)
            {
                programEnd(-1, moveIndex, isWin);
            }
        }
        public void programEnd(int type, int moveIndex, bool isWin)
        {
            if (type == -1) { MessageBox.Show("Remis"); }
            else if (type == 1) { MessageBox.Show("Wygrał A"); }
            else if (type == 2) { MessageBox.Show("Wygrał B"); }
            buttonPlace1.Enabled = false;
            buttonPlace2.Enabled = false;
            buttonPlace3.Enabled = false;
            buttonPlace4.Enabled = false;
            buttonPlace5.Enabled = false;
            buttonPlace6.Enabled = false;
            buttonPlace7.Enabled = false;
            buttonPlace8.Enabled = false;
            buttonPlace9.Enabled = false;
        }
        private void buttonBack_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Close();
        }

        private void buttonPlace1_Click(object sender, EventArgs e)
        {
            if (isChanged[0] != true)
            {
                if ((moveIndex % 2) == 0)
                {
                    buttonPlace1.Image = tictactoe.Properties.Resources.krzyzyk;
                    tab[0, 0] = 1;
                }
                if ((moveIndex % 2) != 0)
                {
                    buttonPlace1.Image = tictactoe.Properties.Resources.kolko;
                    tab[0, 0] = 2;
                }
                moveIndex++;
                isChanged[0] = true;
            }
            winCheck();
        }

        private void buttonPlace2_Click(object sender, EventArgs e)
        {
            if (isChanged[1] != true)
            {
                if ((moveIndex % 2) == 0)
                {
                    buttonPlace2.Image = tictactoe.Properties.Resources.krzyzyk;
                    tab[0, 1] = 1;
                }
                if ((moveIndex % 2) != 0)
                {
                    buttonPlace2.Image = tictactoe.Properties.Resources.kolko;
                    tab[0, 1] = 2;
                }
                moveIndex++;
                isChanged[1] = true;
            }
            winCheck();
        }

        private void buttonPlace3_Click(object sender, EventArgs e)
        {
            if (isChanged[2] != true)
            {
                if ((moveIndex % 2) == 0)
                {
                    buttonPlace3.Image = tictactoe.Properties.Resources.krzyzyk;
                    tab[0, 2] = 1;
                }
                if ((moveIndex % 2) != 0)
                {
                    buttonPlace3.Image = tictactoe.Properties.Resources.kolko;
                    tab[0, 2] = 2;
                }
                moveIndex++;
                isChanged[2] = true;
            }
            winCheck();
        }

        private void buttonPlace4_Click(object sender, EventArgs e)
        {
            if (isChanged[3] != true)
            {
                if ((moveIndex % 2) == 0)
                {
                    buttonPlace4.Image = tictactoe.Properties.Resources.krzyzyk;
                    tab[1, 0] = 1;
                }
                if ((moveIndex % 2) != 0)
                {
                    buttonPlace4.Image = tictactoe.Properties.Resources.kolko;
                    tab[1, 0] = 2;
                }
                moveIndex++;
                isChanged[3] = true;
            }
            winCheck();
        }

        private void buttonPlace5_Click(object sender, EventArgs e)
        {
            if (isChanged[4] != true)
            {
                if ((moveIndex % 2) == 0)
                {
                    buttonPlace5.Image = tictactoe.Properties.Resources.krzyzyk;
                    tab[1, 1] = 1;
                }
                if ((moveIndex % 2) != 0)
                {
                    buttonPlace5.Image = tictactoe.Properties.Resources.kolko;
                    tab[1, 1] = 2;
                }
                moveIndex++;
                isChanged[4] = true;
            }
            winCheck();
        }

        private void buttonPlace6_Click(object sender, EventArgs e)
        {
            if (isChanged[5] != true)
            {
                if ((moveIndex % 2) == 0)
                {
                    buttonPlace6.Image = tictactoe.Properties.Resources.krzyzyk;
                    tab[1, 2] = 1;
                }
                if ((moveIndex % 2) != 0)
                {
                    buttonPlace6.Image = tictactoe.Properties.Resources.kolko;
                    tab[1, 2] = 2;
                }
                moveIndex++;
                isChanged[5] = true;
            }
            winCheck();
        }

        private void buttonPlace7_Click(object sender, EventArgs e)
        {
            if (isChanged[6] != true)
            {
                if ((moveIndex % 2) == 0)
                {
                    buttonPlace7.Image = tictactoe.Properties.Resources.krzyzyk;
                    tab[2, 0] = 1;
                }
                if ((moveIndex % 2) != 0)
                {
                    buttonPlace7.Image = tictactoe.Properties.Resources.kolko;
                    tab[2, 0] = 2;
                }
                moveIndex++;
                isChanged[6] = true;
            }
            winCheck();
        }

        private void buttonPlace8_Click(object sender, EventArgs e)
        {
            if (isChanged[7] != true)
            {
                if ((moveIndex % 2) == 0)
                {
                    buttonPlace8.Image = tictactoe.Properties.Resources.krzyzyk;
                    tab[2, 1] = 1;
                }
                if ((moveIndex % 2) != 0)
                {
                    buttonPlace8.Image = tictactoe.Properties.Resources.kolko;
                    tab[2, 1] = 2;
                }
                moveIndex++;
                isChanged[7] = true;
            }
            winCheck();
        }

        private void buttonPlace9_Click(object sender, EventArgs e)
        {
            if (isChanged[8] != true)
            {
                if ((moveIndex % 2) == 0)
                {
                    buttonPlace9.Image = tictactoe.Properties.Resources.krzyzyk;
                    tab[2, 2] = 1;
                }
                if ((moveIndex % 2) != 0)
                {
                    buttonPlace9.Image = tictactoe.Properties.Resources.kolko;
                    tab[2, 2] = 2;
                }
                moveIndex++;
                isChanged[8] = true;
            }
            winCheck();
        }
    }
}
