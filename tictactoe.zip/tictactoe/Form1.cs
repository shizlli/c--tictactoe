﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tictactoe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            playerAvatar1.Image = tictactoe.Properties.Resources.avatar1;
            playerAvatar2.Image = tictactoe.Properties.Resources.avatar4;
        }
        int avatarIndex1 = 0;
        int avatarIndex2 = 0;

        public void changeAvatar(int avatarIndex, int type)
        {
            if (type == 1)
            {
                if (avatarIndex == 0) { playerAvatar1.Image = tictactoe.Properties.Resources.avatar1; }
                if (avatarIndex == 1) { playerAvatar1.Image = tictactoe.Properties.Resources.avatar2; }
                if (avatarIndex == 2) { playerAvatar1.Image = tictactoe.Properties.Resources.avatar3; }
            }
            if (type == 2)
            {
                if (avatarIndex == 0) { playerAvatar2.Image = tictactoe.Properties.Resources.avatar4; }
                if (avatarIndex == 1) { playerAvatar2.Image = tictactoe.Properties.Resources.avatar5; }
                if (avatarIndex == 2) { playerAvatar2.Image = tictactoe.Properties.Resources.avatar6; }
            }
        }
        private void arrowLeft1_Click(object sender, EventArgs e)
        {
            if(avatarIndex1 == 0) { avatarIndex1 = 2; }
            else { avatarIndex1--; }
            changeAvatar(avatarIndex1, 1);
        }
        private void arrowRight1_Click(object sender, EventArgs e)
        {
            if (avatarIndex1 == 2) { avatarIndex1 = 0; }
            else {  avatarIndex1++; }
            changeAvatar(avatarIndex1, 1);
        }

        private void arrowLeft2_Click(object sender, EventArgs e)
        {
            if (avatarIndex2 == 0) { avatarIndex2 = 2; }
            else { avatarIndex2--; }
            changeAvatar(avatarIndex2, 2);
        }

        private void arrowRight2_Click(object sender, EventArgs e)
        {
            if (avatarIndex2 == 2) { avatarIndex2 = 0; }
            else { avatarIndex2++; }
            changeAvatar(avatarIndex2, 2);
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Start_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(playerNameTextBox1.Text, playerNameTextBox2.Text, playerAvatar1.Image, playerAvatar2.Image);
            form2.Show();
            Hide();
        }
    }
}
