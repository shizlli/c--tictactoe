﻿namespace tictactoe
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.arrowLeft1 = new System.Windows.Forms.Button();
            this.arrowRight1 = new System.Windows.Forms.Button();
            this.arrowRight2 = new System.Windows.Forms.Button();
            this.arrowLeft2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.playerNameTextBox1 = new System.Windows.Forms.TextBox();
            this.playerNameTextBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Start = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.playerAvatar2 = new System.Windows.Forms.PictureBox();
            this.playerAvatar1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.playerAvatar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerAvatar1)).BeginInit();
            this.SuspendLayout();
            // 
            // arrowLeft1
            // 
            this.arrowLeft1.Location = new System.Drawing.Point(23, 127);
            this.arrowLeft1.Name = "arrowLeft1";
            this.arrowLeft1.Size = new System.Drawing.Size(23, 23);
            this.arrowLeft1.TabIndex = 0;
            this.arrowLeft1.Text = "<";
            this.arrowLeft1.UseVisualStyleBackColor = true;
            this.arrowLeft1.Click += new System.EventHandler(this.arrowLeft1_Click);
            // 
            // arrowRight1
            // 
            this.arrowRight1.Location = new System.Drawing.Point(160, 127);
            this.arrowRight1.Name = "arrowRight1";
            this.arrowRight1.Size = new System.Drawing.Size(23, 23);
            this.arrowRight1.TabIndex = 1;
            this.arrowRight1.Text = ">";
            this.arrowRight1.UseVisualStyleBackColor = true;
            this.arrowRight1.Click += new System.EventHandler(this.arrowRight1_Click);
            // 
            // arrowRight2
            // 
            this.arrowRight2.Location = new System.Drawing.Point(456, 127);
            this.arrowRight2.Name = "arrowRight2";
            this.arrowRight2.Size = new System.Drawing.Size(23, 23);
            this.arrowRight2.TabIndex = 4;
            this.arrowRight2.Text = ">";
            this.arrowRight2.UseVisualStyleBackColor = true;
            this.arrowRight2.Click += new System.EventHandler(this.arrowRight2_Click);
            // 
            // arrowLeft2
            // 
            this.arrowLeft2.Location = new System.Drawing.Point(321, 127);
            this.arrowLeft2.Name = "arrowLeft2";
            this.arrowLeft2.Size = new System.Drawing.Size(23, 23);
            this.arrowLeft2.TabIndex = 3;
            this.arrowLeft2.Text = "<";
            this.arrowLeft2.UseVisualStyleBackColor = true;
            this.arrowLeft2.Click += new System.EventHandler(this.arrowLeft2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(160, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "CS:GO TICTACTOE";
            // 
            // playerNameTextBox1
            // 
            this.playerNameTextBox1.Location = new System.Drawing.Point(54, 218);
            this.playerNameTextBox1.Name = "playerNameTextBox1";
            this.playerNameTextBox1.Size = new System.Drawing.Size(100, 20);
            this.playerNameTextBox1.TabIndex = 7;
            // 
            // playerNameTextBox2
            // 
            this.playerNameTextBox2.Location = new System.Drawing.Point(350, 218);
            this.playerNameTextBox2.Name = "playerNameTextBox2";
            this.playerNameTextBox2.Size = new System.Drawing.Size(100, 20);
            this.playerNameTextBox2.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 202);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Player 1:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(356, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Player 2:";
            // 
            // Start
            // 
            this.Start.Location = new System.Drawing.Point(270, 299);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(75, 34);
            this.Start.TabIndex = 11;
            this.Start.Text = "Start";
            this.Start.UseVisualStyleBackColor = true;
            this.Start.Click += new System.EventHandler(this.Start_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(160, 299);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 34);
            this.Exit.TabIndex = 12;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // playerAvatar2
            // 
            this.playerAvatar2.BackgroundImage = global::tictactoe.Properties.Resources.avatar6;
            this.playerAvatar2.Location = new System.Drawing.Point(350, 88);
            this.playerAvatar2.Name = "playerAvatar2";
            this.playerAvatar2.Size = new System.Drawing.Size(100, 100);
            this.playerAvatar2.TabIndex = 5;
            this.playerAvatar2.TabStop = false;
            // 
            // playerAvatar1
            // 
            this.playerAvatar1.BackgroundImage = global::tictactoe.Properties.Resources.avatar1;
            this.playerAvatar1.Location = new System.Drawing.Point(54, 88);
            this.playerAvatar1.Name = "playerAvatar1";
            this.playerAvatar1.Size = new System.Drawing.Size(100, 100);
            this.playerAvatar1.TabIndex = 2;
            this.playerAvatar1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::tictactoe.Properties.Resources.tloStart;
            this.ClientSize = new System.Drawing.Size(504, 411);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Start);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.playerNameTextBox2);
            this.Controls.Add(this.playerNameTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.playerAvatar2);
            this.Controls.Add(this.arrowRight2);
            this.Controls.Add(this.arrowLeft2);
            this.Controls.Add(this.playerAvatar1);
            this.Controls.Add(this.arrowRight1);
            this.Controls.Add(this.arrowLeft1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.playerAvatar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerAvatar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button arrowLeft1;
        private System.Windows.Forms.Button arrowRight1;
        private System.Windows.Forms.PictureBox playerAvatar1;
        private System.Windows.Forms.PictureBox playerAvatar2;
        private System.Windows.Forms.Button arrowRight2;
        private System.Windows.Forms.Button arrowLeft2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox playerNameTextBox1;
        private System.Windows.Forms.TextBox playerNameTextBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Start;
        private System.Windows.Forms.Button Exit;
    }
}

